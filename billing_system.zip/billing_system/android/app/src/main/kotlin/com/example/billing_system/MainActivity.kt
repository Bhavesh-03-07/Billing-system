package com.example.billing_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
